package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.base.BaseActivity;
import com.example.myapplication.base.BaseRecyclerAdapter;
import com.example.myapplication.base.MyRVViewHolder;
import com.example.myapplication.bean.EventBus_Tag;
import com.example.myapplication.bean.GoodsBean;
import com.example.myapplication.util.ToastUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class   ManaShopActivity extends BaseActivity {

    @BindView(R.id.lv)
    RecyclerView lv;
    @BindView(R.id.tv_add)
    TextView tv_add;

    private List<GoodsBean> itemBeanList = new ArrayList();
    private MyAdapter myAdapter;

    @Override
    protected void setContent() {
        super.setContent();
        setContentView(R.layout.activity_mana_shop);
        ButterKnife.bind(this);
        registerEventBus();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void initData() {
        //init listview
        itemBeanList.clear();
        List<GoodsBean> temp = DataSupport.findAll(GoodsBean.class);//查询表Comment
        itemBeanList.addAll(temp);
        @SuppressLint("WrongConstant")
        LinearLayoutManager manager = new LinearLayoutManager(ManaShopActivity.this, LinearLayoutManager.VERTICAL, false);
        if (null == manager)
            return;
        lv.setLayoutManager(manager);
        myAdapter = new MyAdapter(ManaShopActivity.this, itemBeanList, R.layout.item_meal3);
        lv.setAdapter(myAdapter);
    }

    @Override
    protected void initListener() {
        tv_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                new QQDialog(getActivity(), 0).showDialog();
                startActivity(new Intent(ManaShopActivity.this, AddInfoActivity.class));
            }
        });
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    class MyAdapter extends BaseRecyclerAdapter<GoodsBean> {

        private TextView tv_list_item, tv_1, tv_2, tv_3, tv_price;
        private ImageView imgv_list;
        private int selPosi;

        public void setSelPosi(int selPosi) {
            this.selPosi = selPosi;
        }

        public MyAdapter(Context context, List<GoodsBean> datas, int layoutId) {
            super(context, datas, layoutId);
        }

        @Override
        public void setView(MyRVViewHolder holder, GoodsBean bean, int position) {
            if (null == holder || null == bean)
                return;
            //init view
            imgv_list = holder.getView(R.id.imgv_list);
            tv_list_item = holder.getView(R.id.tv_list_item);
            tv_1 = holder.getView(R.id.tv_1);
            tv_2 = holder.getView(R.id.tv_2);
            tv_3 = holder.getView(R.id.tv_3);
            tv_price = holder.getView(R.id.tv_price);
            TextView tv_del = holder.getView(R.id.tv_del);
            TextView tv_update = holder.getView(R.id.tv_update);
            //set view
            tv_list_item.setText(bean.getGoods_name()+"\n"+bean.getGoods_name2());
            tv_1.setText("类型：" + bean.getRemark());
            tv_price.setText(bean.getGoods_price() + "元");

            imgv_list.setImageResource(bean.getGoods_pic());
            tv_del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DataSupport.deleteAll(GoodsBean.class, "goods_id = ? ", bean.getGoods_id());
                    ToastUtil.showToast(ManaShopActivity.this, "删除成功");
                    EventBus.getDefault().post(new EventBus_Tag(111));
                }
            });

            tv_update.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ManaShopActivity.this, AddInfoActivity.class);
                    intent.putExtra("bean",bean);
                    startActivity(intent);
                }
            });
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(EventBus_Tag event) {
        switch (event.getTag()) {
            case 111:
                itemBeanList.clear();
                List<GoodsBean> temp = DataSupport.findAll(GoodsBean.class);//查询表Comment
                itemBeanList.addAll(temp);
                myAdapter.notifyDataSetChanged();
                break;
        }
    }

    public void registerEventBus() {
        EventBus.getDefault().unregister(this);
        EventBus.getDefault().register(this);
    }


}