package com.example.myapplication;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

import com.example.myapplication.base.BaseFragment;
import com.example.myapplication.base.MyApplication;
import com.example.myapplication.util.ToastUtil;
import com.example.myapplication.widgts.CustomDialog;
import com.example.myapplication.widgts.DialogUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

import static android.content.Context.BIND_AUTO_CREATE;
import static android.content.Context.LOCATION_SERVICE;

public class   MeFragment extends BaseFragment {

    @BindView(R.id.tv_buy)
    TextView tv_buy;
    @BindView(R.id.tv_reset)
    TextView tv_reset;
    @BindView(R.id.tv_exit)
    TextView tv_exit;
    @BindView(R.id.tv_mana)
    TextView tv_mana;

    @BindView(R.id.tv_dingwei)
    TextView tv_dingwei;


    public MeFragment() {

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_three, container, false);
        ButterKnife.bind(this, view);

        initData();
        return view;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initData() {
        if (MyApplication.curStype==0){
            tv_buy.setVisibility(View.VISIBLE);
            tv_reset.setVisibility(View.VISIBLE);
            tv_mana.setVisibility(View.GONE);
            tv_dingwei.setVisibility(View.GONE);
        }else {
            tv_buy.setVisibility(View.GONE);
            tv_reset.setVisibility(View.GONE);
            tv_mana.setVisibility(View.VISIBLE);
            tv_dingwei.setVisibility(View.VISIBLE);
        }
        tv_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), OrderActivity.class));
            }
        });
        tv_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), ResetActivity.class));

            }
        });
        tv_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), LoginActivity.class));
                getActivity().finish();
            }
        });


        tv_mana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), ManaShopActivity.class));
            }
        });

        tv_dingwei.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), OrderActivity.class));
            }
        });





    }



}
