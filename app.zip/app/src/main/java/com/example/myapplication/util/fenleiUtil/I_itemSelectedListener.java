package com.example.myapplication.util.fenleiUtil;

/**
 * Created by seven on 2017/2/22.
 */

public interface I_itemSelectedListener {
    void onItemSelected(int currentPosition);
}
