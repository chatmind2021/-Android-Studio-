package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.base.BaseFragment;
import com.example.myapplication.base.BaseRecyclerAdapter;
import com.example.myapplication.base.MyApplication;
import com.example.myapplication.base.MyRVViewHolder;
import com.example.myapplication.bean.GoodsBean;
import com.example.myapplication.bean.GoodsBeanMy;
import com.example.myapplication.util.DateUtil;
import com.example.myapplication.util.ToastUtil;

import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class   HomeFragment extends BaseFragment {
    @BindView(R.id.lv)
    RecyclerView lv;


    private List<GoodsBean> itemBeanList = new ArrayList();
    private MyAdapter myAdapter;

    public HomeFragment() {

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_one, container, false);
        ButterKnife.bind(this, view);
        initData();
        return view;
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initData() {
        initAdapter();

    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initAdapter() {
        List<GoodsBean> temp = DataSupport.findAll(GoodsBean.class);//查询表Comment
        if (temp.size() == 0) {
            for (int i = 0; i < 4; i++) {
                GoodsBean bean = new GoodsBean();
                String name = "";
                String name2 = "";
                String stype = "";
                double goods_price = 0;
                int pic = 0;
                if (i % 4 == 0) {
                    name = "原果汁";
                    name2 = "用新鲜水果采用机械方法直接取得的汁液称为原果汁";
                    goods_price = 6;
                    stype = "饮料";
                    pic = R.mipmap.f1;
                } else if (i % 4 == 1) {
                    name = "烧鹅";
                    name2 = "鹅以乌鬃鹅为优，去翼、脚、内脏的整鹅，吹气，涂五香料，缝肚，滚水烫皮，过冷水，糖水匀皮，晾风而后腌制，最后挂在烤炉里或明火上转动烤成，斩件上碟，便可进食。";
                    goods_price = 45;
                    stype = "熟食";
                    pic = R.mipmap.f5;
                } else if (i % 4 == 2) {
                    name = "白菜";
                    name2 = "白菜营养丰富，菜叶可供炒食、生食、盐腌、酱渍，外层脱落的菜叶尚可作饲料，  具有一定的药用价值。";
                    goods_price = 21;
                    stype = "蔬菜";
                    pic = R.mipmap.f8;
                } else if (i % 4 == 3) {
                    name = "茅台酒";
                    name2 = "茅台酒是中国的传统特产酒。与苏格兰威士忌、法国科涅克白兰地齐名的世界三大蒸馏名酒之一，同时是中国三大名酒“茅五剑”之一。也是大曲酱香型白酒的鼻祖，已有800多年的历史。";
                    goods_price = 12;
                    stype = "烟酒";
                    pic = R.mipmap.f11;
                }
                bean.setGoods_name(name);  bean.setGoods_name2(name2);
                bean.setGoods_pic(pic);
                bean.setRemark(stype);
                bean.setGoods_price(goods_price);
                bean.setGoods_id(System.currentTimeMillis() + "");
                bean.save();
                itemBeanList.add(bean);
            }
        } else {
            itemBeanList.addAll(temp);
        }

        //init listview
        @SuppressLint("WrongConstant")
        LinearLayoutManager manager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        if (null == manager)
            return;
        lv.setLayoutManager(manager);
        myAdapter = new MyAdapter(getActivity(), itemBeanList, R.layout.item_meal);
        lv.setAdapter(myAdapter);
        myAdapter.setOnItemClickListener(new BaseRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent = new Intent(getActivity(), GoodInfoActivity.class);
                intent.putExtra("bean",itemBeanList.get(position));
                startActivity(intent);
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    class MyAdapter extends BaseRecyclerAdapter<GoodsBean> {

        private TextView tv_list_item, tv_1, tv_2, tv_3, tv_price, tv_add;
        private ImageView imgv_list;
        private int selPosi;

        public void setSelPosi(int selPosi) {
            this.selPosi = selPosi;
        }

        public MyAdapter(Context context, List<GoodsBean> datas, int layoutId) {
            super(context, datas, layoutId);
        }

        @Override
        public void setView(MyRVViewHolder holder, GoodsBean bean, int position) {
            if (null == holder || null == bean)
                return;
            //init view
            imgv_list = holder.getView(R.id.imgv_list);
            tv_list_item = holder.getView(R.id.tv_list_item);
            tv_1 = holder.getView(R.id.tv_1);
            tv_2 = holder.getView(R.id.tv_2);
            tv_3 = holder.getView(R.id.tv_3);
            tv_price = holder.getView(R.id.tv_price);
            tv_add = holder.getView(R.id.tv_add);
            //set view
            tv_list_item.setText(bean.getGoods_name()+"\n"+bean.getGoods_name2());
            tv_1.setText("类型：" + bean.getRemark());
            tv_price.setText(bean.getGoods_price() + "元");
            imgv_list.setImageResource(bean.getGoods_pic());

            if (MyApplication.curStype==0){
                tv_add.setVisibility(View.VISIBLE);
            }else {
                tv_add.setVisibility(View.GONE);
            }
            tv_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    new BuyDialog(getActivity(), bean).showDialog();

                    AlertDialog dialog;
                    dialog = new AlertDialog.Builder(getActivity())
                            .setTitle("支付提醒")  //设置标题
                            .setIcon(R.mipmap.lgo) //设置图标
                            .setMessage("本次需要支付：" + bean.getGoods_price() + "元") //提示信息
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    GoodsBeanMy tempBean = new GoodsBeanMy();
                                    tempBean.setUserName(MyApplication.curUser);
                                    tempBean.setmTime(DateUtil.getTodayData_3());
                                    tempBean.setGoods_id(bean.getGoods_id());
                                    tempBean.setRemark(bean.getRemark());
                                    tempBean.setGoods_price(bean.getGoods_price());
                                    tempBean.setGoods_name2(bean.getGoods_name2());
                                    tempBean.setGoods_name(bean.getGoods_name());
                                    tempBean.setGoods_pic(bean.getGoods_pic());

                                    tempBean.save();
                                    if (tempBean.isSaved()) {
                                        ToastUtil.showToast(getActivity(), "购买成功");
                                    }

                                    dialog.dismiss();
                                }
                            })   //添加“确定”按钮
                            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })   //添加“取消”按钮
                            .create();  //创建对话框
                    dialog.show();  //显示对话框


                }
            });


        }
    }


}
