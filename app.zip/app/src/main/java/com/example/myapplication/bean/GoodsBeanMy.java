package com.example.myapplication.bean;

import org.litepal.crud.DataSupport;

/**
 * @Author: Paper
 */
public class GoodsBeanMy extends DataSupport {

    private String goods_id;
    private String goods_name;
    private String goods_name2;

    private double goods_price;
    private int goods_num;
    private int goods_pic;
    private String goods_type;
    private String goods_ladu;
    private String remark;

    private String mTime;


    public String getGoods_name2() {
        return goods_name2;
    }

    public void setGoods_name2(String goods_name2) {
        this.goods_name2 = goods_name2;
    }

    private String userName;


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getGoods_name() {
        return goods_name;
    }

    public void setGoods_name(String goods_name) {
        this.goods_name = goods_name;
    }

    public double getGoods_price() {
        return goods_price;
    }

    public void setGoods_price(double goods_price) {
        this.goods_price = goods_price;
    }

    public int getGoods_num() {
        return goods_num;
    }

    public void setGoods_num(int goods_num) {
        this.goods_num = goods_num;
    }

    public int getGoods_pic() {
        return goods_pic;
    }

    public void setGoods_pic(int goods_pic) {
        this.goods_pic = goods_pic;
    }

    public String getGoods_type() {
        return goods_type;
    }

    public void setGoods_type(String goods_type) {
        this.goods_type = goods_type;
    }

    public String getGoods_ladu() {
        return goods_ladu;
    }

    public void setGoods_ladu(String goods_ladu) {
        this.goods_ladu = goods_ladu;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


    public String getmTime() {
        return mTime;
    }

    public void setmTime(String mTime) {
        this.mTime = mTime;
    }
}
