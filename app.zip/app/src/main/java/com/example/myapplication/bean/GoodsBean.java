package com.example.myapplication.bean;

import org.litepal.crud.DataSupport;

import java.io.Serializable;

/**
 * @anthor : 大海
 * 每天进步一点点
 * @description :
 */


public class  GoodsBean extends DataSupport implements Serializable {

    private String goods_id;
    private String goods_name;//名称
    private String goods_name2;//内容
    private double goods_price;

    private int goods_pic;

    private String remark;//类型


    public String getGoods_name2() {
        return goods_name2;
    }

    public void setGoods_name2(String goods_name2) {
        this.goods_name2 = goods_name2;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }


    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getGoods_name() {
        return goods_name;
    }

    public void setGoods_name(String goods_name) {
        this.goods_name = goods_name;
    }

    public double getGoods_price() {
        return goods_price;
    }

    public void setGoods_price(double goods_price) {
        this.goods_price = goods_price;
    }


    public int getGoods_pic() {
        return goods_pic;
    }

    public void setGoods_pic(int goods_pic) {
        this.goods_pic = goods_pic;
    }
}
