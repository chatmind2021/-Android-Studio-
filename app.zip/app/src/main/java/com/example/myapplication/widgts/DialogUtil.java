package com.example.myapplication.widgts;


import android.content.Context;
import android.content.DialogInterface;
import android.view.WindowManager;

import com.example.myapplication.util.DisplayUtil;
import com.example.myapplication.util.ScreenUtils;

/**
 */
public class DialogUtil {

    /*两个按钮带标题*/
    public static CustomDialog showDialog(final Context context, CustomDialog dialog, int button, String title, String message,String PositiveMessage, String NegetiveMessage, DialogInterface.OnClickListener positiveListener, DialogInterface.OnClickListener Negativelistener) {

        if (dialog == null) {
            CustomDialog.Builder builder = new CustomDialog.Builder(context, button);
            builder.setMessage(message);
            builder.setTitle(title);
            builder.setPositiveButton(PositiveMessage, positiveListener);
            builder.setNegativeButton(NegetiveMessage, Negativelistener);


            dialog = builder.create();

            WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
            params.width = ScreenUtils.getScreenW(context) - DisplayUtil.dip2px(context, 76);
            dialog.getWindow().setAttributes(params);
        }

        return dialog;
    }
}
