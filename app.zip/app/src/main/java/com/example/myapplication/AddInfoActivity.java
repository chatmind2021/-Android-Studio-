package com.example.myapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.base.BaseActivity;
import com.example.myapplication.bean.EventBus_Tag;
import com.example.myapplication.bean.GoodsBean;
import com.example.myapplication.util.StrUtil;
import com.example.myapplication.util.ToastUtil;
import com.example.myapplication.util.fenleiUtil.I_itemSelectedListener;
import com.example.myapplication.util.fenleiUtil.ItemChooseUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class   AddInfoActivity extends BaseActivity {

    @BindView(R.id.edt_0)
    EditText edt_0;
    @BindView(R.id.edt_1)
    EditText edt_1;
    @BindView(R.id.edt_price)
    EditText edt_price;
    @BindView(R.id.edt_kll)
    TextView edt_kll;
    @BindView(R.id.imgv_pic)
    ImageView imgv_pic;
    @BindView(R.id.tv_login)
    TextView tv_login;

    @BindView(R.id.tv_title)
    TextView tv_title;
    private List<String> list_type;  //类别
    private String[] str_type = new String[]{
            "饮料", "熟食", "蔬菜", "水果", "烟酒", "衣服", "生活用品"  };
    private int pic = R.mipmap.lgo;
    GoodsBean bean;

    @Override
    protected void setContent() {
        super.setContent();
        setContentView(R.layout.activity_add_pic);
        ButterKnife.bind(this);
        registerEventBus();
    }

    @Override
    protected void initData() {
        bean = (GoodsBean) getIntent().getSerializableExtra("bean");
        if (bean == null) {
            tv_title.setText("添加商品信息");
        } else {
            tv_title.setText("修改商品信息");
            edt_0.setText(bean.getGoods_name());
            edt_1.setText(bean.getGoods_name2());
            edt_price.setText(bean.getGoods_price() + "");
            edt_kll.setText(bean.getRemark());
            pic = bean.getGoods_pic();
            imgv_pic.setImageResource(pic);

        }

        //类别
        list_type = new ArrayList();
        list_type = Arrays.asList(str_type);
        edt_kll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ItemChooseUtil.showItemWheel(AddInfoActivity.this, list_type, "类型", 0, new I_itemSelectedListener() {
                    @Override
                    public void onItemSelected(int currentPosition) {
                        edt_kll.setText(list_type.get(currentPosition));
                    }
                });
            }
        });

        imgv_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddInfoActivity.this, ChoicePicActivity.class));
            }
        });

        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp0 = edt_0.getText().toString().trim();
                String temp1 = edt_1.getText().toString().trim();
                String tempPrice = edt_price.getText().toString().trim();
                String tempPwd = edt_kll.getText().toString().trim();
                if (StrUtil.isEmpty(temp0) ||StrUtil.isEmpty(temp1) || StrUtil.isEmpty(tempPwd) || StrUtil.isEmpty(tempPrice)) {
                    ToastUtil.showToast(myActivity, "输入内容不完整");
                    return;
                }
                if (bean == null) {
                    GoodsBean tempBean = new GoodsBean();
                    tempBean.setGoods_name(temp0);
                    tempBean.setGoods_name2(temp1);
                    tempBean.setGoods_price(Double.parseDouble(tempPrice));
                    tempBean.setRemark(tempPwd);
                    tempBean.setGoods_pic(pic);
                    tempBean.setGoods_id(System.currentTimeMillis() + "");
                    tempBean.save();
                    if (tempBean.isSaved()) {
                        ToastUtil.showToast(myActivity, "添加成功");
                    }
                } else {
                    ContentValues values = new ContentValues();
                    values.put("goods_name", temp0);
                    values.put("goods_name2", temp1);
                    values.put("goods_price", Double.parseDouble(tempPrice));
                    values.put("remark", tempPwd);
                    values.put("goods_pic", pic);
                    DataSupport.updateAll(GoodsBean.class, values, "goods_id = ?", bean.getGoods_id());
                    ToastUtil.showToast(myActivity, "修改成功");
                }
                EventBus.getDefault().post(new EventBus_Tag(111));
                finish();
            }

        });

    }

    @Override
    protected void initListener() {

    }

    public void registerEventBus() {
        EventBus.getDefault().unregister(this);
        EventBus.getDefault().register(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(EventBus_Tag event) {
        switch (event.getTag()) {
            case 2:
                imgv_pic.setImageResource(event.getPosition());
                pic = event.getPosition();
                break;
        }
    }
}
