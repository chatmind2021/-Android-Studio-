package com.example.myapplication;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.myapplication.base.BaseActivity;
import com.example.myapplication.base.MyApplication;
import com.example.myapplication.bean.EventBus_Tag;
import com.example.myapplication.bean.GoodsBean;
import com.example.myapplication.bean.GoodsBeanMy;
import com.example.myapplication.util.DateUtil;
import com.example.myapplication.util.ToastUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class GoodInfoActivity extends BaseActivity {

    @BindView(R.id.edt_0)
    TextView edt_0;
    @BindView(R.id.edt_1)
    TextView edt_1;
    @BindView(R.id.edt_price)
    TextView edt_price;
    @BindView(R.id.edt_kll)
    TextView edt_kll;
    @BindView(R.id.imgv_pic)
    ImageView imgv_pic;
    @BindView(R.id.tv_login)
    TextView tv_login;

    @BindView(R.id.tv_title)
    TextView tv_title;
    @BindView(R.id.tv_pl)
    TextView tv_pl;
    private int pic = R.mipmap.lgo;
    GoodsBean bean;

    @Override
    protected void setContent() {
        super.setContent();
        setContentView(R.layout.activity_goodinfo);
        ButterKnife.bind(this);
        registerEventBus();
    }

    @Override
    protected void initData() {
        tv_title.setText("商品详情");
        bean = (GoodsBean) getIntent().getSerializableExtra("bean");
        if (bean != null) {

            edt_0.setText(bean.getGoods_name());
            edt_1.setText(bean.getGoods_name2());
            edt_price.setText(bean.getGoods_price() + "");
            edt_kll.setText(bean.getRemark());
            pic = bean.getGoods_pic();
            imgv_pic.setImageResource(pic);

        }


        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoodsBeanMy tempBean = new GoodsBeanMy();
                tempBean.setUserName(MyApplication.curUser);
                tempBean.setmTime(DateUtil.getTodayData_3());
                tempBean.setGoods_id(bean.getGoods_id());
                tempBean.setRemark(bean.getRemark());
                tempBean.setGoods_price(bean.getGoods_price());
                tempBean.setGoods_name2(bean.getGoods_name2());
                tempBean.setGoods_name(bean.getGoods_name());
                tempBean.setGoods_pic(bean.getGoods_pic());

                tempBean.save();
                if (tempBean.isSaved()) {
                    ToastUtil.showToast(GoodInfoActivity.this, "购买成功");
                    finish();
                }


            }

        });

        tv_pl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TalkActivity.start(GoodInfoActivity.this, bean.getGoods_name(), bean.getGoods_id() );

            }
        });

    }

    @Override
    protected void initListener() {

    }

    public void registerEventBus() {
        EventBus.getDefault().unregister(this);
        EventBus.getDefault().register(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventMainThread(EventBus_Tag event) {
        switch (event.getTag()) {
            case 2:

                break;
        }
    }
}
